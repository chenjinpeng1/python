#_*_coding:utf-8_*_
__author__ = 'Alex Li'



from modules.base_module import BaseSaltModule

class UserModule(BaseSaltModule):
    pass