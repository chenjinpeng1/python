from django.apps import AppConfig


class RobbConfig(AppConfig):
    name = 'Robb'
