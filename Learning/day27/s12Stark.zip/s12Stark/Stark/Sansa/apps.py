from django.apps import AppConfig


class SansaConfig(AppConfig):
    name = 'Sansa'
