
$.fn.dataTable.AutoFill.classes.btn = 'btn btn-primary';
