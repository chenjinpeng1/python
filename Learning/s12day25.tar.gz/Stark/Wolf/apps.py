from django.apps import AppConfig


class WolfConfig(AppConfig):
    name = 'Wolf'
