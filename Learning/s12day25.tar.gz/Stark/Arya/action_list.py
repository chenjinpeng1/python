#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:Alex Li
from Arya.plugins import cmd,state
actions = {
    'cmd': cmd.CMD,
    'state':state.State
}