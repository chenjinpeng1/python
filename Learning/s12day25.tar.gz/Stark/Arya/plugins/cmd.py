#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:Alex Li

from Arya.backends.base_module import BaseSaltModule
class CMD(BaseSaltModule):
    print('in cmd module ')