#coding:utf-8

import tornado.httpserver
import tornado.ioloop
import tornado.options
import tornado.web
import tornado.httpclient

import os
import json

from tornado.options import define, options

#定义全局可以使用的选项port，调用方式options.port, 或者从外部传递参数
define("port", default=8000, help="run on the given port", type=int)



class IndexHandler(tornado.web.RequestHandler):
    def get(self):
        fjson = open('test.json', 'r')
        jsondata = json.loads(fjson.read())
        fjson.close()
        self.render("index.html", backenddata = jsondata)

if __name__ == "__main__":
    SETTINGS = dict(
        template_path = os.path.join(os.path.dirname(__file__), "templates"),
        static_path = os.path.join(os.path.dirname(__file__), "static"),
    )
    urls = [
        (r"/", IndexHandler),
    ]
    tornado.options.parse_command_line()
    app = tornado.web.Application(
        handlers=urls,
        **SETTINGS
    )
    http_server = tornado.httpserver.HTTPServer(app)
    http_server.listen(options.port)
    tornado.ioloop.IOLoop.instance().start()
