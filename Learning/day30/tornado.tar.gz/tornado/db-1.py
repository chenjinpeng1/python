import torndb
db=torndb.Connection("127.0.0.1", "shipman", "root", "oldboy@123")
a=db.get('select * from con_usage where id=5 ')
b=db.query('select * from con_usage ')
print(a)
print(b)
