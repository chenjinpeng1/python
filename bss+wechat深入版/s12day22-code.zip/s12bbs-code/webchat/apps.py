from django.apps import AppConfig


class WebchatConfig(AppConfig):
    name = 'webchat'
