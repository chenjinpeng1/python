from django.contrib import admin
from webchat import models
# Register your models here.


admin.site.register(models.WebGroup)